#pragma once

#include <stdint.h>
#include "libsmp.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct SmpStaticBuffer SmpStaticBuffer;
struct SmpStaticBuffer {

    uint8_t *data;     /* pointer to the data */
    size_t maxsize;    /* size of the memory pointed by data */
    void * free;
    bool statically_allocated;
};
typedef struct SmpStaticContext SmpStaticContext;
struct SmpStaticContext {

    void *decoder;
    int device;

    void *cbs[2];
    void *userdata;

    bool opened;

    bool statically_allocated;
    void *msg_tx;
    void *serial_tx;
    void *msg_rx;
};
typedef struct SmpStaticMessage SmpStaticMessage;
struct SmpStaticMessage {

    /** The message id */
    uint32_t msgid;

    SmpValue values[SMP_MESSAGE_MAX_VALUES];
    SmpValue *pvalues;
    size_t capacity;

    bool statically_allocated;
};
typedef struct SmpStaticSerialProtocolDecoder SmpStaticSerialProtocolDecoder;
struct SmpStaticSerialProtocolDecoder {

    int state;

    uint8_t *buf;
    size_t bufsize;
    size_t offset;
    size_t maxsize;

    bool statically_allocated;
};
#ifdef __cplusplus
}
#endif