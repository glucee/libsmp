#pragma once

/* The maximum number of arguments in a message */
#define SMP_MESSAGE_MAX_VALUES 8

