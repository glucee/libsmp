#pragma once

/* The maximum number of arguments in a message */
#define SMP_MESSAGE_MAX_VALUES 8

/* The maximum frame size in bytes */
#define SMP_SERIAL_FRAME_MAX_FRAME_SIZE 128

